const mongoose = require('mongoose');

const vendorSchema = new mongoose.Schema({
  name: String,
  shopName: String,
  phone: String,
  email: String,
  aadhaarNumber: String,
  panNumber: String,
  gstNumber: String,
  address: String,
  location: Object,
  plan: String,
  registrationDate: String,
  status: { type: String, default: 'pending' }
});

module.exports = mongoose.model('Vendor', vendorSchema);
