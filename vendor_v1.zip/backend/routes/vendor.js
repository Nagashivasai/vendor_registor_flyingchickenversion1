const express = require('express');
const Vendor = require('../models/Vendor');
const verifyAdmin = require('../middleware/verifyAdmin');
const router = express.Router();

// Register vendor
router.post('/', async (req, res) => {
  const vendor = new Vendor(req.body);
  await vendor.save();
  res.json({ success: true, vendor });
});

// Get all vendors (admin only)
router.get('/', verifyAdmin, async (req, res) => {
  const vendors = await Vendor.find();
  res.json(vendors);
});

// Update vendor status (admin only)
router.patch('/:id', verifyAdmin, async (req, res) => {
  const { status } = req.body;
  await Vendor.findByIdAndUpdate(req.params.id, { status });
  res.json({ success: true });
});

module.exports = router;
