const express = require('express');
const router = express.Router();

// Payment stub
router.post('/', (req, res) => {
  // Integrate with payment gateway here
  res.json({ success: true });
});

module.exports = router;
